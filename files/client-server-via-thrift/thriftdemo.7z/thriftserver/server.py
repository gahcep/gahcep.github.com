import sys
sys.path.append("./gen-py")

# Thrift facility
from thrift.protocol import TBinaryProtocol
from thrift.transport import TTransport
from thrift.transport import TSocket
from thrift.server import TServer

# CalcService
import calc_simple.CalcService
from calc_simple.ttypes import *

# Calc Handler
class CalcHandler(calc_simple.CalcService.Iface):
    def addition(self, First, Second):
        res = CalcResult()
        res.result = First + Second
        return res

def main():

    # Set the main facility to operate with our Handlers
    processor = calc_simple.CalcService.Processor(CalcHandler())

    # Define the socket
    transport = TSocket.TServerSocket(port=9910)

    # Buffering is critical. Raw sockets are very slow
    tfactory = TTransport.TBufferedTransportFactory()

    # Wrap in a protocol
    pfactory = TBinaryProtocol.TBinaryProtocolFactory()

    # Create a Server
    server = TServer.TThreadedServer(processor, transport, tfactory, pfactory)

    try:
        # Launch a Server
        print 'Starting the server...'
        server.serve()

    except (KeyboardInterrupt, SystemExit):
        print "Quitting from keyboard interrupt"
        transport.close()

    except Exception, e:
        print e

if __name__ == '__main__':
    main()
