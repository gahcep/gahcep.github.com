namespace csharp Calc.Simple
namespace py calc_simple

struct CalcResult {
    1: i32 result
}

service CalcService {
    CalcResult addition(1: i32 first, 2: i32 second)
}
