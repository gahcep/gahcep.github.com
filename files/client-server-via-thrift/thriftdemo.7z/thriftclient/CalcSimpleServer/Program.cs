﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Thrift;
using Thrift.Transport;
using Thrift.Protocol;

using Calc.Simple;

namespace CalcSimpleServer
{
    class Program
    {
        static void Main(string[] args)
        {
            TSocket socket = new TSocket("192.168.18.133", 9910);
            TBufferedTransport transport = new TBufferedTransport(socket);

            TProtocol proto = new TBinaryProtocol(transport);
            CalcService.Client client = new CalcService.Client(proto);

            transport.Open();

            var res = client.addition(100, 200);

            Console.WriteLine(res.Result.ToString());
            Console.ReadKey();
        }
    }
}
